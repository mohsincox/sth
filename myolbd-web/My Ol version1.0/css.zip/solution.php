

<!DOCTYPE html>
<html lang="en" data-ng-app="website">
<head>
    
    
            <meta charset="utf-8">
        <title>MYOLBD</title>
        <link rel="SHORTCUT ICON" href="images/mt-1806-favicon.ico?_build=1557140742" type="image/vnd.microsoft.icon" />

                                    
<!-- <link rel="canonical" href="https://template80168.motopreview.com/" /> -->
<meta property="og:title" content="Home"/>
<!-- <meta property="og:url" content="https://template80168.motopreview.com/"/> -->
                            <meta http-equiv="X-UA-Compatible" content="IE=Edge"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    
            <link rel="stylesheet" href="css/assets.min.css?_build=1552389959"/>
        <style>
@import url(//fonts.googleapis.com/css?family=Montserrat:100,100italic,200,200italic,300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic|Open+Sans:300,300italic,regular,italic,600,600italic,700,700italic,800,800italic&subset=latin);
</style>
        <link rel="stylesheet" href="css/styles.css?_build=1556371712" id="moto-website-style"/>
            
    
    
    <link rel="stylesheet" href="css/font-awesome.min.css"/>

    
   

   
    
    
    
    
</head>
<body class="moto-background moto-website_live">
        
             

    <div class="page">


        <section id="section-content" class="content page-1 moto-section" data-widget="section" data-container="section">
                                    <div class="moto-widget moto-widget-block moto-bg-color5_5 moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto" data-widget="block" data-spacing="sasa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row">
            <div class="moto-cell col-sm-12" data-container="container">
                
            <div class="moto-widget moto-widget-row row-fixed moto-justify-content_center moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-grid-type="sm" data-widget="row" data-spacing="aaaa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        



        <?php
    		include 'menu.php';
		?>

		
    </div>
</div></div>
        </div>
    </div>
</div>


<!-- 
<div class="moto-widget moto-widget-block moto-spacing-top-large moto-spacing-right-auto moto-spacing-bottom-large moto-spacing-left-auto" data-widget="block" data-spacing="lala" style="background-image:url(images/mt-1806-content-bg01.jpg);background-position:top;background-repeat:no-repeat;background-size:cover;" data-bg-position="top" data-bg-image="images/mt-1806-content-bg01.jpg">
    
    
    <div class="container-fluid">
        <div class="row">
            <div class="moto-cell col-sm-12" data-container="container">
                
            <div data-widget-id="wid_1556093695_11z9zcpaw" class="moto-widget moto-widget-spacer moto-preset-default moto-spacing-top-large moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto moto-visible-on_tablet"
    data-widget="spacer" data-preset="default" data-spacing="lama" data-visible-on="tablet">
    <div class="moto-widget-spacer-block" style="height:10px"></div>
</div><div class="moto-widget moto-widget-row row-fixed moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-grid-type="sm" data-widget="row" data-spacing="aaaa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-sm-9 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="aama" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable">
        <p class="moto-text_system_5">Site is in development mode&nbsp;&nbsp;<span class="moto-color1_3">—</span></p>
        <p class="moto-text_system_5"><span class="moto-color1_3">—</span></p>
        <h1 class="moto-text_system_4"></h1></div>
</div><div class="moto-widget moto-widget-row moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-grid-type="sm" data-widget="row" data-spacing="aaaa"  data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-sm-4 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-row row-gutter-0 moto-justify-content_center moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto" data-grid-type="xs" data-widget="row" data-spacing="sasa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-4 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div data-widget-id="wid_1556093382_fqj2vqqbj" class="moto-widget moto-widget-image moto-preset-default moto-align-center moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small  " data-widget="image">
                        <span class="moto-widget-image-link">
                
            </span>
            </div></div><div class="moto-widget moto-widget-row__column moto-cell col-xs-8 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top"><div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small" data-widget="text" data-preset="default" data-spacing="aaas" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_system_9"></p></div>
</div>
    
    
</div>

                
            
        </div>
    </div>
</div></div><div class="moto-widget moto-widget-row__column moto-cell col-sm-4 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-row row-gutter-0 moto-justify-content_center moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto" data-grid-type="xs" data-widget="row" data-spacing="sasa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-4 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div data-widget-id="wid_1556093445_pj4t845iu" class="moto-widget moto-widget-image moto-preset-default moto-align-center moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small  " data-widget="image">
                        <span class="moto-widget-image-link">
                
            </span>
            </div>
        
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-8 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small" data-widget="text" data-preset="default" data-spacing="aaas" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_system_9"></p></div>
</div>
        
    
</div>

                
            
        </div>
    </div>
</div></div><div class="moto-widget moto-widget-row__column moto-cell col-sm-4 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-row row-gutter-0 moto-justify-content_center moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto" data-grid-type="xs" data-widget="row" data-spacing="sasa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-4 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div data-widget-id="wid_1556093607_8udrge32h" class="moto-widget moto-widget-image moto-preset-default moto-align-center moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small  " data-widget="image">
                        <span class="moto-widget-image-link">
                
            </span>
            </div>
        
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-8 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small" data-widget="text" data-preset="default" data-spacing="aaas" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_system_9"></p></div>
</div>
        
    
</div>

                
            
        </div>
    </div>
</div></div>

                
            
        </div>
    </div>
</div>

</div><div class="moto-widget moto-widget-row__column moto-cell col-sm-3 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
</div>

                
            
        </div>
    </div>
</div><div data-widget-id="wid_1556093684_el17c8xb9" class="moto-widget moto-widget-spacer moto-preset-default moto-spacing-top-large moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto moto-visible-on_tablet"
    data-widget="spacer" data-preset="default" data-spacing="laaa" data-visible-on="tablet">
    <div class="moto-widget-spacer-block" style="height:10px"></div>
</div></div>
        </div>
    </div>
</div>



 -->
































<!-- <div class="moto-widget moto-widget-block moto-spacing-top-medium moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto" data-widget="block" data-spacing="mama" style="background-image:url(images/mt-1806-content-bg02.jpg);background-position:center;background-repeat:no-repeat;background-size:cover;" data-bg-position="center" data-bg-image="images/mt-1806-content-bg02.jpg"><a class="moto-anchor" name="contact-us"></a>
    
    
    <div class="container-fluid">
        <div class="row">
            <div class="moto-cell col-sm-12" data-container="container">
                
            <div class="moto-widget moto-widget-row row-fixed moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-grid-type="sm" data-widget="row" data-spacing="aaaa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-sm-4 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="sasa" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><h3 class="moto-text_system_8" style="text-align: center;">Call Now</h3></div>
</div><div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="aasa" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_system_12" style="text-align: center;"><span class="fa"></span>&nbsp;&nbsp;<a href="tel:1234567890" data-action="call" class="moto-link">Hotline: +880 9610-223344</a></p>
        <p class="moto-text_system_12" style="text-align: center;"><span class="fa"></span>&nbsp;&nbsp;<a href="tel:1234567890" data-action="call" class="moto-link">Tel: +8802 55033889, 55035340</a>
        </p>
    </div>
</div></div><div class="moto-widget moto-widget-row__column moto-cell col-sm-4 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-container moto-container_content_5cc01c081" data-widget="container" data-container="container" data-css-name="moto-container_content_5cc01c081" data-bg-position="left top">
    
    
    
<div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="sasa" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><h3 class="moto-text_system_8" style="text-align: center;">Request a Callback</h3></div>
</div><div data-widget-id="wid_1556094136_jwa4p09kg" class="moto-widget moto-widget-contact_form moto-preset-3 moto-spacing-top-auto moto-spacing-right-medium moto-spacing-bottom-auto moto-spacing-left-medium  " data-preset="3" data-widget="contact_form" data-spacing="amam">
        <div ng-controller="widget.ContactForm.Controller" ng-init="hash = '2@eyJoIjoiK1hRTnRCZEduSk9XNzBNZnpuTVBNUWg2UitYMzlCWG1CekJ4OUxDSWNMaz0iLCJpIjoiV2U1dWFaYnBsUTJnNSt5MFdRMUUyUT09IiwidiI6IkZUSWVYOVwvN3lBQnliWnVKcWowakcxY0oxWG1JZTRMRmpFQ1NES2NJR0FYQmo2bWdFRHVMVG5FTDlIcXVJKytnY0lvQ0xWdnljMEl2RDlTb0g2TllyUT09In0=';actionAfterSubmission={&quot;action&quot;:&quot;none&quot;,&quot;url&quot;:&quot;&quot;,&quot;target&quot;:&quot;_self&quot;,&quot;id&quot;:&quot;&quot;};resetAfterSubmission=false">
                <form class="moto-widget-contact_form-form" role="form" name="contactForm" ng-submit="submit()" novalidate>
            <div ng-show="sending" class="contact-form-loading"></div>

                            
                            
                                                                        <div class="moto-widget-contact_form-group">
                            <label for="field_phone" class="moto-widget-contact_form-label">Phone</label>
                            <input type="text" class="moto-widget-contact_form-field moto-widget-contact_form-input" placeholder="Phone *"  ng-blur="validate('phone')" required  ng-model-options="{ updateOn: 'blur' }" name="phone" id="field_phone" ng-model="message.phone"/>
                                                            <span class="moto-widget-contact_form-field-error ng-cloak" ng-cloak ng-show="contactForm.phone.$invalid && !contactForm.phone.$pristine && !contactForm.phone.emailInvalid" >Field is required</span>
                                                                                    </div>
                                    
                            
                            
                            
                            
                            
            
                            <div class="moto-widget-contact_form-success ng-cloak" ng-cloak ng-show="emailSent">
                    Your message was sent successfully
                </div>
                <div class="moto-widget-contact_form-danger ng-cloak" ng-cloak ng-show="emailError">
                    Sorry, your message was not sent
                </div>
                        <div class="moto-widget-contact_form-buttons">

                            <div class="moto-widget moto-widget-button moto-preset-2 moto-align-center" data-preset="2" data-align="center">
                    <a ng-click="submit();" class="moto-widget-button-link moto-size-small" data-size="small"><span class="fa moto-widget-theme-icon"></span><span class="moto-widget-button-label">Request</span></a>
                </div>
                <button type="submit" class="hidden"></button>
            
            </div>
        </form>
    </div>
    </div></div></div><div class="moto-widget moto-widget-row__column moto-cell col-sm-4 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="sasa" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><h3 class="moto-text_system_8" style="text-align: center;">Email</h3></div>
</div><div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="aasa" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_system_12" style="text-align: center;"><span class="fa"></span>&nbsp;&nbsp;<a href="mailto:demo@demolink.com" data-action="mail" class="moto-link">info@myolbd.com</a></p>
        
    </div>
</div></div>

                
            
        </div>
    </div>
</div></div>
        </div>
    </div>
</div>



 -->

























<div class="moto-widget moto-widget-block moto-spacing-top-large moto-spacing-right-auto moto-spacing-bottom-large moto-spacing-left-auto" data-widget="block" data-spacing="lala" style="" data-bg-position="left top"><a class="moto-anchor" name="offers"></a>
    
    
    <div class="container-fluid">
        <div class="row">
            <div class="moto-cell col-sm-12" data-container="container">
                
            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-small moto-spacing-bottom-auto moto-spacing-left-small" data-widget="text" data-preset="default" data-spacing="asas" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable">
    	<!-- <p class="moto-text_system_11" style="text-align: center;">WHAT WE OFFER</p> -->
    	<h2 class="moto-text_system_6" style="text-align: center;">Our <strong>Solutions</strong></h2></div>
</div><div class="moto-widget moto-widget-row row-fixed moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-grid-type="sm" data-widget="row" data-spacing="aaaa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-sm-3 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-row row-gutter-0 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-grid-type="xs" data-widget="row" data-spacing="aaaa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-1 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
</div><div class="moto-widget moto-widget-row__column moto-cell col-xs-9 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div data-widget-id="wid_1556094575_80sllmk0k" class="moto-widget moto-widget-divider moto-preset-2 moto-align-left moto-spacing-top-medium moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto  " data-widget="divider_horizontal" data-preset="2">
    <hr class="moto-widget-divider-line" style="max-width:100%;width:100%;">
</div></div><div class="moto-widget moto-widget-row__column moto-cell col-xs-2 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
</div>

                
            
        </div>
    </div>
</div><div class="moto-widget moto-widget-container moto-container_content_5cc01e893" data-widget="container" data-container="container" data-css-name="moto-container_content_5cc01e893" data-bg-position="center">
    
    
    
<div class="moto-widget moto-widget-row row-gutter-0 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-large moto-spacing-left-auto" data-grid-type="xs" data-widget="row" data-spacing="aala" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-1 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
</div><div class="moto-widget moto-widget-row__column moto-cell col-xs-9 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="background-color:rgba(0, 0, 0, 0.7);" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-medium moto-spacing-right-small moto-spacing-bottom-medium moto-spacing-left-small" data-widget="text" data-preset="default" data-spacing="msms" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><h3 class="moto-text_system_13">Call Center Solutions</h3><p class="moto-text_normal">&nbsp;</p><p class="moto-text_normal"><span class="moto-color5_5">Our call center solutions are customized to meet up your specifications and ensure better satisfaction. We are staffed by experienced and professional customer care representatives, expert management.</span></p></div>
</div></div><div class="moto-widget moto-widget-row__column moto-cell col-xs-2 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
</div>

                
            
        </div>
    </div>
</div><div data-widget-id="wid_1556094746_hojzq31rb" class="moto-widget moto-widget-spacer moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto moto-visible-on_desktop"
    data-widget="spacer" data-preset="default" data-spacing="aaaa" data-visible-on="desktop">
    <div class="moto-widget-spacer-block" style="height:100px"></div>
</div></div></div>

                
            
        <div class="moto-widget moto-widget-row__column moto-cell col-sm-3 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-row row-gutter-0 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-grid-type="xs" data-widget="row" data-spacing="aaaa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-1 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-9 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div data-widget-id="wid_1556094893_kwm8jic1i" class="moto-widget moto-widget-divider moto-preset-2 moto-align-left moto-spacing-top-medium moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto  " data-widget="divider_horizontal" data-preset="2">
    <hr class="moto-widget-divider-line" style="max-width:100%;width:100%;">
</div>
        
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-2 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
</div>

                
            
        </div>
    </div>
</div>
        
    
        
            <div class="moto-widget moto-widget-container moto-container_content_5cc01fad5" data-widget="container" data-container="container" data-css-name="moto-container_content_5cc01fad5" data-bg-position="center">
    
    
    
        
            <div class="moto-widget moto-widget-row row-gutter-0 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-large moto-spacing-left-auto" data-grid-type="xs" data-widget="row" data-spacing="aala" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-1 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-9 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="background-color:rgba(0, 0, 0, 0.7);" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-medium moto-spacing-right-small moto-spacing-bottom-medium moto-spacing-left-small" data-widget="text" data-preset="default" data-spacing="msms" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><h3 class="moto-text_system_13">iPBX Solutions</h3><p class="moto-text_normal">&nbsp;</p><p class="moto-text_normal" style="margin-bottom: 38px;"><span class="moto-color5_5">iPBX is a complete telephony system that provides telephone calls over IP data networks. It is a full-featured IP-PBX office phone system based on Open source technology.</span></p><p class="moto-text_normal">&nbsp;</p></div>
</div>
        
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-2 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
</div>

                
            
        </div>
    </div>
</div>
        
    
        
            <div data-widget-id="wid_1556094893_uium5stme" class="moto-widget moto-widget-spacer moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto moto-visible-on_desktop"
    data-widget="spacer" data-preset="default" data-spacing="aaaa" data-visible-on="desktop">
    <div class="moto-widget-spacer-block" style="height:100px"></div>
</div>
        
    
</div>
        
    
</div><div class="moto-widget moto-widget-row__column moto-cell col-sm-3 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-row row-gutter-0 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-grid-type="xs" data-widget="row" data-spacing="aaaa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-1 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-9 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div data-widget-id="wid_1556094892_f3e0en4j0" class="moto-widget moto-widget-divider moto-preset-2 moto-align-left moto-spacing-top-medium moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto  " data-widget="divider_horizontal" data-preset="2">
    <hr class="moto-widget-divider-line" style="max-width:100%;width:100%;">
</div>
        
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-2 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
</div>

                
            
        </div>
    </div>
</div>
        
    
        
            <div class="moto-widget moto-widget-container moto-container_content_5cc01fac4" data-widget="container" data-container="container" data-css-name="moto-container_content_5cc01fac4" data-bg-position="center">
    
    
    
        
            <div class="moto-widget moto-widget-row row-gutter-0 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-large moto-spacing-left-auto" data-grid-type="xs" data-widget="row" data-spacing="aala" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-1 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-9 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="background-color:rgba(0, 0, 0, 0.7);" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-medium moto-spacing-right-small moto-spacing-bottom-medium moto-spacing-left-small" data-widget="text" data-preset="default" data-spacing="msms" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><h3 class="moto-text_system_13">Web Development</h3><p class="moto-text_normal">&nbsp;</p><p class="moto-text_normal"><span class="moto-color5_5">We use best-practice techniques and the latest industry standards when designing and developing all our websites. We make sure our interfaces are designed with communication.&nbsp;</span></p><p class="moto-text_normal">&nbsp;</p></div>
</div>
        
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-2 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
</div>

                
            
        </div>
    </div>
</div>
        
    
        
            <div data-widget-id="wid_1556094892_hymhrfo7k" class="moto-widget moto-widget-spacer moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto moto-visible-on_desktop"
    data-widget="spacer" data-preset="default" data-spacing="aaaa" data-visible-on="desktop">
    <div class="moto-widget-spacer-block" style="height:100px"></div>
</div>
        
    
</div>
        
    
</div><div class="moto-widget moto-widget-row__column moto-cell col-sm-3 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-row row-gutter-0 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-grid-type="xs" data-widget="row" data-spacing="aaaa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-1 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-9 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div data-widget-id="wid_1556094896_4x7cfqyzz" class="moto-widget moto-widget-divider moto-preset-2 moto-align-left moto-spacing-top-medium moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto  " data-widget="divider_horizontal" data-preset="2">
    <hr class="moto-widget-divider-line" style="max-width:100%;width:100%;">
</div>
        
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-2 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
</div>

                
            
        </div>
    </div>
</div>
        
    
        
            <div class="moto-widget moto-widget-container moto-container_content_5cc01fb06" data-widget="container" data-container="container" data-css-name="moto-container_content_5cc01fb06" data-bg-position="center">
    
    
    
        
            <div class="moto-widget moto-widget-row row-gutter-0 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-large moto-spacing-left-auto" data-grid-type="xs" data-widget="row" data-spacing="aala" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-1 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-9 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="background-color:rgba(0, 0, 0, 0.7);" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-medium moto-spacing-right-small moto-spacing-bottom-medium moto-spacing-left-small" data-widget="text" data-preset="default" data-spacing="msms" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><h3 class="moto-text_system_13">Lead Generation</h3><p class="moto-text_normal">&nbsp;</p><p class="moto-text_normal" style="margin-bottom: 19px;"><span class="moto-color5_5">Lead Generation Desktop application for managing Leads from multiple data source. It’s capable of creating; filtering & mining leads with dynamic Flag from call center campaigns.</span></p><p class="moto-text_normal">&nbsp;</p></div>
</div>
        
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-2 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
</div>

                
            
        </div>
    </div>
</div>
        
    
        
            <div data-widget-id="wid_1556094896_nybyrtstu" class="moto-widget moto-widget-spacer moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto moto-visible-on_tablet"
    data-widget="spacer" data-preset="default" data-spacing="aaaa" data-visible-on="tablet">
    <div class="moto-widget-spacer-block" style="height:54px"></div>
</div>
        
    
<div data-widget-id="wid_1556097617_xnuxb4bni" class="moto-widget moto-widget-spacer moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto moto-visible-on_desktop"
    data-widget="spacer" data-preset="default" data-spacing="aaaa" data-visible-on="desktop">
    <div class="moto-widget-spacer-block" style="height:46px"></div>
</div></div>
        
    
</div></div>
    </div>
</div></div>
        </div>
    </div>
</div>





































<!-- <div class="moto-widget moto-widget-block moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-widget="block" data-spacing="aaaa" style="background-color: #F4F4F4;" data-bg-position="center" data-bg-image="images/mt-1806-content-bg03.jpg"><a class="moto-anchor" name="overview"></a>
    
    
    <div class="container-fluid">
        <div class="row">
            <div class="moto-cell col-sm-12" data-container="container">
                
            <div class="moto-widget moto-widget-row row-fixed moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-grid-type="sm" data-widget="row" data-spacing="aaaa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-sm-0 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
</div><div class="moto-widget moto-widget-row__column moto-cell col-sm-12 moto-spacing-top-large moto-spacing-right-auto moto-spacing-bottom-large moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="lala" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="aama" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_system_11">OVERVIEW</p><h2 class="moto-text_system_6">MY <strong>Outsourcing </strong>Limited</h2></div>
</div><div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="aaaa" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_normal">MY Group of Companies, a renowned conglomerate dealing mainly with IT enabled products and services Since 2009, recently launched its latest venture -- MY Outsourcing Ltd – a BPO/Contact Center service provider with a vision to change the way people do business and serve their clients. It specializes in offering contact center services, Back Office Support With robust infrastructure. We manage all our projects as efficiently as possible with conviction. 


</p><p class="moto-text_normal">We value the latest technological developments to meet the growing needs of our customers. In that regard, we involve innovative techniques like call blending, voice logging, soft phone, IVR, ACD, dialer software and many more to offer improved service for our clients and meet their contact center/BPO outsourcing requirements.</p></div>
</div><div class="moto-widget moto-widget-row moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-grid-type="sm" data-widget="row" data-spacing="aaaa" style="" data-bg-position="left top" data-draggable-disabled="">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
            <div class="moto-widget moto-widget-row__column moto-cell col-sm-6 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">


                <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-medium moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small" style="padding-top: 10px;" data-widget="text" data-preset="default" data-spacing="maas" data-animation="" data-draggable-disabled="">
                    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_system_14">What We Do</p><p class="moto-text_normal"><br></p>
                       
                        <p>We specialize in offering all forms of the contact center/Business Process Outsourcing services. Our main focus is on process optimization that ensures all clients to get reduced costs while converting their business operations for a sustainable benefit. We emphasize on increasing the profitability and the efficiency meeting needs of our diverse patrons. </p>
                        <br>
                        <br>
                       
                    </div>
                </div>

            </div>

            <div class="moto-widget moto-widget-row__column moto-cell col-sm-6 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">


                <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-medium moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small" style="padding-top: 10px;" data-widget="text" data-preset="default" data-spacing="maas" data-animation="" data-draggable-disabled="">
                    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_system_14">Infrastructure and security</p><p class="moto-text_normal"><br></p>

                      
                       <p>We have state-of-the-art computing and communications technology, with UPS for power backup, as well as our own power generators in the event of power failure. The Internet and telecom technologies in our delivery centers provide the perfect platform for customer service and support on par with industry.</p>
                        <br>
                        
                    </div>
                </div>

            </div>


                
            
        </div>



        <div class="row" data-container="container">
            
                
            <div class="moto-widget moto-widget-row__column moto-cell col-sm-6 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">


                <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-medium moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small" style="padding-top: 0px;" data-widget="text" data-preset="default" data-spacing="maas" data-animation="" data-draggable-disabled="">
                    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_system_14">Confidentiality and Privacy</p><p class="moto-text_normal"><br></p>
                        
                        <p>At MYOL, we are sensitive to customer concerns and ensure absolute confidentiality and privacy of any information that is given to us. Customers can specify their preferred mode of contact with us, and we will not disclose their identity without their express or written consent. </p>
                        <br>
                        <br>
                       
                    </div>
                </div>

            </div>

            <div class="moto-widget moto-widget-row__column moto-cell col-sm-6 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">


                <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-medium moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small" style="padding-top: 0px;" data-widget="text" data-preset="default" data-spacing="maas" data-animation="" data-draggable-disabled="">
                    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_system_14">Our Partner</p><p class="moto-text_normal"><br></p>

                       
                       <p>MY Outsourcing Limited signed on with <a href="https://www.spok.com" target="_blank">SPOK</a> as an alliance partner in Bangladesh. Spok, Inc., a wholly owned subsidiary of Spok Holdings, Inc. (NASDAQ: SPOK), headquartered in Springfield, Va., is proud to be a leader in critical communications for healthcare, government, public safety, and other industries.</p>
                        <br>
                        
                    </div>
                </div>

            </div>


                
            
        </div>





    </div>
</div></div>

                
            
        </div>
    </div>
</div></div>
        </div>
    </div>
</div>


 -->































<!-- <div class="moto-widget moto-widget-block moto-spacing-top-medium moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto" data-widget="block" data-spacing="mama" style="" data-bg-position="left top"><a class="moto-anchor" name="gallery"></a>
    
    
    <div class="container-fluid">
        <div class="row">
            <div class="moto-cell col-sm-12" data-container="container">
                
            <div id="wid_1556099757_lh3lp26wv" data-widget-id="wid_1556099757_lh3lp26wv" class="moto-widget moto-widget-tile-gallery moto-preset-default moto-spacing-top-auto moto-spacing-right-medium moto-spacing-bottom-auto moto-spacing-left-medium  " data-widget="tile_gallery" data-preset="default">
            <div class="moto-widget-tile-gallery__wrapper">
            <div class="moto-widget-tile-gallery__items-wrapper" data-moto-init-lightbox-gallery="" data-tile-gallery-justify-height=""  data-tile-gallery-show-counter="">
                                    <div class="moto-widget-tile-gallery__item-wrapper">
                        <div class="moto-widget-tile-gallery__item" data-moto-lightbox-item="">
                            <a href="images/mt-1806-gallery-img01bg.jpg"   data-action="lightbox" class="moto-widget-tile-gallery__item-link moto-link" data-moto-lightbox-link="">
                                <img class="moto-widget-tile-gallery__item-image" src="images/mt-1806-gallery-img01.jpg" alt="mt-1806-gallery-img01.jpg"/>
                            </a>
                            <div class="moto-widget-tile-gallery__item-layer">
                                <span class="moto-widget-tile-gallery__item-layer-icon fa"></span>
                                                            </div>
                        </div>
                    </div>
                                    <div class="moto-widget-tile-gallery__item-wrapper">
                        <div class="moto-widget-tile-gallery__item" data-moto-lightbox-item="">
                            <a href="images/mt-1806-gallery-img02bg.jpg"   data-action="lightbox" class="moto-widget-tile-gallery__item-link moto-link" data-moto-lightbox-link="">
                                <img class="moto-widget-tile-gallery__item-image" src="images/mt-1806-gallery-img02.jpg" alt="mt-1806-gallery-img02.jpg"/>
                            </a>
                            <div class="moto-widget-tile-gallery__item-layer">
                                <span class="moto-widget-tile-gallery__item-layer-icon fa"></span>
                                                            </div>
                        </div>
                    </div>
                                    <div class="moto-widget-tile-gallery__item-wrapper">
                        <div class="moto-widget-tile-gallery__item" data-moto-lightbox-item="">
                            <a href="images/mt-1806-gallery-img03bg.jpg"   data-action="lightbox" class="moto-widget-tile-gallery__item-link moto-link" data-moto-lightbox-link="">
                                <img class="moto-widget-tile-gallery__item-image" src="images/mt-1806-gallery-img03.jpg" alt="mt-1806-gallery-img03.jpg"/>
                            </a>
                            <div class="moto-widget-tile-gallery__item-layer">
                                <span class="moto-widget-tile-gallery__item-layer-icon fa"></span>
                                                            </div>
                        </div>
                    </div>
                                    <div class="moto-widget-tile-gallery__item-wrapper">
                        <div class="moto-widget-tile-gallery__item" data-moto-lightbox-item="">
                            <a href="images/mt-1806-gallery-img04bg.jpg"   data-action="lightbox" class="moto-widget-tile-gallery__item-link moto-link" data-moto-lightbox-link="">
                                <img class="moto-widget-tile-gallery__item-image" src="images/mt-1806-gallery-img04.jpg" alt="mt-1806-gallery-img04.jpg"/>
                            </a>
                            <div class="moto-widget-tile-gallery__item-layer">
                                <span class="moto-widget-tile-gallery__item-layer-icon fa"></span>
                                                            </div>
                        </div>
                    </div>
                            </div>
            <style type="text/css">
                                #wid_1556099757_lh3lp26wv .moto-widget-tile-gallery__items-wrapper {
column-gap:20px;
column-count:4;
}

                #wid_1556099757_lh3lp26wv .moto-widget-tile-gallery__item-wrapper {
padding-bottom:20px;
}

                @media screen and (max-width: 1039px) {
                #wid_1556099757_lh3lp26wv .moto-widget-tile-gallery__items-wrapper {
column-gap:10px;
}

                #wid_1556099757_lh3lp26wv .moto-widget-tile-gallery__item-wrapper {
padding-bottom:10px;
}

                }
                @media screen and (max-width: 767px) {
                #wid_1556099757_lh3lp26wv .moto-widget-tile-gallery__items-wrapper {
column-count:2;
}

                
                }
                @media screen and (max-width: 479px) {
                #wid_1556099757_lh3lp26wv .moto-widget-tile-gallery__items-wrapper {
column-count:1;
}

                
                }
            </style>
        </div>
    </div></div>
        </div>
    </div>
</div> -->












<!-- <div class="moto-widget moto-widget-block moto-spacing-top-large moto-spacing-right-auto moto-spacing-bottom-large moto-spacing-left-auto" data-widget="block" data-spacing="lala" style="background-image:url(images/mt-1806-content-bg05.jpg);background-position:top;background-repeat:no-repeat;background-size:cover;" data-bg-position="top" data-bg-image="images/mt-1806-content-bg05.jpg"><a class="moto-anchor" name="testimonials"></a>
    
    
    <div class="container-fluid">
        <div class="row">
            <div class="moto-cell col-sm-12" data-container="container">
                
                    
                        <div class="moto-widget moto-widget-row row-fixed moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-grid-type="sm" data-widget="row" data-spacing="aaaa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-sm-4 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="sasa" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_system_11">WHAT PEOPLE SAY</p><h2 class="moto-text_system_6"><strong>Testimonials</strong></h2></div>
</div>
        
    
        
            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-medium moto-spacing-bottom-medium moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="amma" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_186">&nbsp;</p></div>
</div>
        
    
        
            
        
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-sm-8 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-row moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-grid-type="sm" data-widget="row" data-spacing="aaaa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-sm-12 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-row row-gutter-0 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-grid-type="xs" data-widget="row" data-spacing="aaaa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-1 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-4 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div data-widget-id="wid_1556099993_3o63q6blk" class="moto-widget moto-widget-divider moto-preset-2 moto-align-left moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto  " data-widget="divider_horizontal" data-preset="2">
    <hr class="moto-widget-divider-line" style="max-width:100%;width:100%;">
</div>
        
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-7 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
</div>

                
            
        </div>
    </div>
</div>
        
    
        
            <div class="moto-widget moto-widget-row row-gutter-0 moto-bg-color5_3 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-grid-type="sm" data-widget="row" data-spacing="aaaa" style="" data-bg-position="top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-sm-12 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-row moto-justify-content_bottom moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-grid-type="xs" data-widget="row" data-spacing="aaaa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-1 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-4 moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto" style="background-color:rgba(0, 0, 0, 0.7);" data-widget="row.column" data-container="container" data-spacing="sasa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-small moto-spacing-right-small moto-spacing-bottom-small moto-spacing-left-small" data-widget="text" data-preset="default" data-spacing="ssss" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_system_13" style="text-align: center;">Rayeed H.</p></div>
</div>
        
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-7 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-medium moto-spacing-bottom-auto moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="amaa" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_system_6" style="text-align: right;"><span class="moto-color1_3"><span class="fa"></span></span></p></div>
</div></div>

                
            
        </div>
    </div>
</div><div class="moto-widget moto-widget-row moto-spacing-top-medium moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto" data-grid-type="xs" data-widget="row" data-spacing="mama" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-1 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
</div><div class="moto-widget moto-widget-row__column moto-cell col-xs-11 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-medium moto-spacing-bottom-auto moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="amaa" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_system_14"><em>We have a strategic partnership with MY Outsourcing Limited which works extremely well. Together we are inventing a new customer communication channel to enhance the customer experience and provide a human face to the web…</em></p></div>
</div></div>

                
            
        </div>
    </div>
</div>
        
    
        
            
        
    
</div>

                
            
        </div>
    </div>
</div>
        
    
</div>

                
            
                
                    

                
            
        </div>
    </div>
</div>
        
    
        
            
        
    
        
            
        
    
</div>

                
            
        </div>
    </div>
</div>
                    
                
            </div>
        </div>
    </div>
</div> -->


























<!-- <div class="moto-widget moto-widget-block moto-bg-color1_3 moto-spacing-top-large moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto" data-widget="block" data-spacing="lama" style="" data-bg-position="left top"><a class="moto-anchor" name="partners"></a>
    
    
    <div class="container-fluid">
        <div class="row">
            <div class="moto-cell col-sm-12" data-container="container">
                
            <div class="moto-widget moto-widget-row row-fixed moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-grid-type="sm" data-widget="row" data-spacing="aaaa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">




    </div>
</div></div>
        </div>
    </div>
</div>
 -->









<!-- 
<div class="moto-widget moto-widget-block moto-spacing-top-medium moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto" data-widget="block" data-spacing="mama" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row">
            <div class="moto-cell col-sm-12" data-container="container">
                
            <div class="moto-widget moto-widget-row row-fixed moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-grid-type="sm" data-widget="row" data-spacing="aaaa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-sm-4 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-row row-gutter-0 moto-justify-content_center moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto" data-grid-type="xs" data-widget="row" data-spacing="sasa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-2 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="aaaa" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_system_6"><span class="moto-color1_3"><span class="fa"></span></span></p></div>
</div></div><div class="moto-widget moto-widget-row__column moto-cell col-xs-10 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small" data-widget="text" data-preset="default" data-spacing="aaas" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_216">Address</p><p class="moto-text_normal"> House 37, Flat A4-A5, Road 27, Block-A Banani, Dhaka 1213.</p></div>
</div></div>

                
            
        </div>
    </div>
</div></div><div class="moto-widget moto-widget-row__column moto-cell col-sm-4 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-row row-gutter-0 moto-justify-content_center moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto" data-grid-type="xs" data-widget="row" data-spacing="sasa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-2 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="aaaa" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_system_6"><span class="moto-color1_3"><span class="fa"></span></span></p></div>
</div>
        
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-10 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top"><div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small" data-widget="text" data-preset="default" data-spacing="aaas" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_216">Phone</p><p class="moto-text_normal"><a data-action="call" class="moto-link" href="tel:1234567890">+880 9610-223344</a></p></div>
</div>
    
    
        
            
        
    
</div>

                
            
        </div>
    </div>
</div></div><div class="moto-widget moto-widget-row__column moto-cell col-sm-4 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-row row-gutter-0 moto-justify-content_center moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto" data-grid-type="xs" data-widget="row" data-spacing="sasa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-2 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="aaaa" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_system_6"><span class="moto-color1_3"><span class="fa"></span></span></p></div>
</div>
        
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-10 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small" data-widget="text" data-preset="default" data-spacing="aaas" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_216">E-mail</p><p class="moto-text_normal"><a data-action="mail" class="moto-link" href="mailto:info@myolbd.com">info@myolbd.com</a></p></div>
</div>
        
    
</div>

                
            
        </div>
    </div>
</div></div>

                
            
        </div>
    </div>
</div></div>
        </div>
    </div>
</div> -->











<?php
	include 'footer.php';

?>










        </section>
    </div>


                     <div data-moto-back-to-top-button class="moto-back-to-top-button">
        <a ng-click="toTop($event)" class="moto-back-to-top-button-link">
            <span class="moto-back-to-top-button-icon fa"></span>
        </a>
    </div>
                
<div data-moto-widget-callback class="moto-widget-callback moto-widget-callback_closed moto-preset-default">
    <div class="moto-widget-callback__wrapper">
        <div class="moto-widget-callback__open-button moto-widget-callback__thumbnail-wrapper moto-widget-callback__thumbnail-wrapper_icon">
            <div class="moto-widget-callback__overlay moto-widget-callback__overlay_open-button"></div>
                        <div class="moto-widget-callback__thumbnail moto-widget-callback__thumbnail_icon fa fa-fw fa-phone"></div>
    
        </div>
        <div class="moto-widget-callback__body moto-widget-callback__body_more-details-enabled" style="display: none;">
            <div class="moto-widget-callback__agent moto-widget-callback__thumbnail-wrapper moto-widget-callback__thumbnail-wrapper_image">
                            <div class="moto-widget-callback__thumbnail moto-widget-callback__thumbnail_image" style="background-image: url(images/mt-1806-tabs-img01.jpg);"></div>
    
            </div>
            <div class="moto-widget-callback__description moto-widget-text">
                <p class="moto-text_system_8" style="text-align: center;"><span class="moto-color_custom1">Sara Dibra</span></p><p class="moto-text_normal" style="text-align: center;">agent</p><p class="moto-text_normal" style="text-align: center;"><a class="moto-link" data-action="call" href="tel:+8809610223344"><span class="fa"></span> +8809610223344</a></p>            </div>
                            <div class="moto-widget-callback__more-details-wrapper">
                    <hr class="moto-widget-callback__more-details-divider">
                    <div class="moto-widget-callback__more-details">
                                                                    <div class="moto-widget-callback__more-details-item">
                            <div class="moto-widget-callback__overlay moto-widget-callback__overlay_link"></div>
                            <a href="https://t.me/#" class="moto-widget-callback__link moto-widget-callback__link-telegram_chat" title="Telegram" target="_blank"></a>
                        </div>
                                                                                            <div class="moto-widget-callback__more-details-item">
                            <div class="moto-widget-callback__overlay moto-widget-callback__overlay_link"></div>
                            <a href="https://wa.me/#" class="moto-widget-callback__link moto-widget-callback__link-whatsapp_chat" title="WhatsApp" target="_blank"></a>
                        </div>
                                                                                            <div class="moto-widget-callback__more-details-item">
                            <div class="moto-widget-callback__overlay moto-widget-callback__overlay_link"></div>
                            <a href="viber://pa/info?uri=#" class="moto-widget-callback__link moto-widget-callback__link-viber_public_account" title="Viber" target="_blank"></a>
                        </div>
                                                                                                                                                                                                                                                                            <div class="moto-widget-callback__more-details-item">
                            <div class="moto-widget-callback__overlay moto-widget-callback__overlay_link"></div>
                            <a href="mailto:#" class="moto-widget-callback__link moto-widget-callback__link-email" title="Email" target="_blank"></a>
                        </div>
                                                                </div>
                </div>
                <div class="moto-widget-callback__more-details-button-wrapper"><i class="moto-widget-callback__more-details-button fa fa-angle-down"></i></div>
                        <div class="moto-widget-callback__close-button">×</div>
        </div>
    </div>
</div>                <script src="js/website.assets.min.js?_build=1556311539" type="text/javascript" data-cfasync="false"></script>
    <script type="text/javascript" data-cfasync="false">
        var websiteConfig = websiteConfig || {};
        websiteConfig.address = 'https://template80168.motopreview.com/';
        websiteConfig.addressHash = '45fc310bac5f5312375f90b298cfe14a';
        websiteConfig.apiUrl = '/api.php';
        websiteConfig.preferredLocale = 'en_US';
        websiteConfig.preferredLanguage = websiteConfig.preferredLocale.substring(0, 2);
                websiteConfig.back_to_top_button = {"topOffset":300,"animationTime":500,"type":"theme"};
                websiteConfig.popup_preferences = {"loading_error_message":"The content could not be loaded."};
        websiteConfig.lazy_loading = {"enabled":true};
        websiteConfig.cookie_notification = {"enabled":false,"content":"<p class=\"moto-text_normal\">This website uses cookies to ensure you get the best experience on our website.<\/p>","content_hash":"6610aef7f7138423e25ee33c75f23279","controls":{"visible":"close,accept","accept":{"label":"Got it","preset":"default","size":"medium","cookie_lifetime":365}}};
                angular.module('website.plugins', []);
    </script>
    <script src="js/website.min.js?_build=1556311537" type="text/javascript" data-cfasync="false"></script>
        <script type="text/javascript">$.fn.motoGoogleMap.setApiKey('AIzaSyAk8PGBXexyvCl_XGQDHqTfrNhZ1zYHFTI');</script>
                
    
    
</body>
</html>