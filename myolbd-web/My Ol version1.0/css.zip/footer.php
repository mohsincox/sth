<div class="moto-widget moto-widget-block moto-bg-color2_1 moto-spacing-top-large moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-widget="block" data-spacing="laaa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row">
            <div class="moto-cell col-sm-12" data-container="container">
                
            <div class="moto-widget moto-widget-row row-fixed moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto" data-grid-type="sm" data-widget="row" data-spacing="aama" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-sm-3 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-row row-gutter-0 moto-justify-content_center moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto" data-grid-type="xs" data-widget="row" data-spacing="aasa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-3 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div data-widget-id="wid_1556107168_0oh633zi7" class="moto-widget moto-widget-image moto-preset-default  moto-spacing-top-auto moto-spacing-right-small moto-spacing-bottom-auto moto-spacing-left-auto  " data-widget="image">
                        <a class="moto-widget-image-link moto-link" href="/"   data-action="page">
                <img data-src="images/ISO_Logo.png" class="moto-widget-image-picture lazyload" data-id="187" title="" alt="">
            </a>
            </div>
        
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-9 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="aaaa" data-animation="">
    <!-- <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_system_1"><a target="_self" href="/" data-action="page" data-id="1" class="moto-link"><span class="moto-color5_5">NODE</span></a></p><p class="moto-text_system_2"><a target="_self" data-action="page" data-id="1" class="moto-link" href="/">Call Center Company</a></p></div> -->
</div>
        
    
</div>

                
            
        </div>
    </div>
</div><div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-medium moto-spacing-bottom-medium moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="amma" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_normal"><span class="moto-color5_5">We specialize in offering all forms of the contact center services. The BPO services on offer at segmented under inbound call center customer service and outbound customer service respectively.</span></p></div>
</div><div id="wid_1556107382_g7ojl38lu" data-widget-id="wid_1556107382_g7ojl38lu" class="moto-widget moto-widget-social-links-extended moto-preset-2 moto-align-left moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto  " data-widget="social_links_extended" data-preset="2">
        <ul class="moto-widget-social-links-extended__list">
                <li class="moto-widget-social-links-extended__item moto-widget-social-links-extended__item-1">
            <a href="https://www.facebook.com/MYOUTSOURCINGLIMITED" class="moto-widget-social-links-extended__link" target="_blank" >
                <span class="moto-widget-social-links-extended__icon fa fa-facebook"></span>
            </a>
        </li>
                <li class="moto-widget-social-links-extended__item moto-widget-social-links-extended__item-2">
            <a href="#" class="moto-widget-social-links-extended__link" target="_self" >
                <span class="moto-widget-social-links-extended__icon fa fa-linkedin-square"></span>
            </a>
        </li>
                <li class="moto-widget-social-links-extended__item moto-widget-social-links-extended__item-3">
            <a href="#" class="moto-widget-social-links-extended__link" target="_self" >
                <span class="moto-widget-social-links-extended__icon fa fa-twitter"></span>
            </a>
        </li>
            </ul>
    <style type="text/css">
                                            </style>
    </div></div>



    <!-- <div class="moto-widget moto-widget-row__column moto-cell col-sm-2 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="sama" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_217"><a target="_self" data-action="page" data-id="1" class="moto-link" href="/">Home</a></p><p class="moto-text_217"><a target="_self" data-action="page" data-id="1" class="moto-link" href="/#services">Services</a></p><p class="moto-text_217"><a target="_self" data-action="page" data-id="1" class="moto-link" href="/#gallery">Gallery</a></p><p class="moto-text_217"><a target="_self" data-action="page" data-id="1" class="moto-link" href="/#pricing">Pricing</a></p><p class="moto-text_217"><a target="_self" data-action="page" data-id="1" class="moto-link" href="/#team">Team</a></p><p class="moto-text_217"><a target="_self" href="/#contact-us" data-action="page" data-id="1" class="moto-link">Contact Us&nbsp;</a></p></div>
</div>
</div> -->



<div class="moto-widget moto-widget-row__column moto-cell col-sm-3 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="saaa" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_system_14"><span class="moto-color5_5">MY Outsourcing Limited</span></p></div>
</div><div class="moto-widget moto-widget-row row-gutter-0 moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-grid-type="xs" data-widget="row" data-spacing="saaa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-1 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="aaaa" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_normal"><span class="moto-color1_3"><span class="fa"></span></span></p></div>
</div></div><div class="moto-widget moto-widget-row__column moto-cell col-xs-11 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small" data-widget="text" data-preset="default" data-spacing="aaas" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_217">House 37, Flat A4-A5, Road 27, Block-A Banani, Dhaka 1213, Bangladesh</p></div>
</div></div>

                
            
        </div>
    </div>
</div><div class="moto-widget moto-widget-row row-gutter-0 moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-grid-type="xs" data-widget="row" data-spacing="saaa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-1 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="aaaa" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_normal"><span class="moto-color1_3"><span class="fa"></span></span></p></div>
</div>
        
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-11 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small" data-widget="text" data-preset="default" data-spacing="aaas" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_217">info@myolbd.com</p></div>
</div>
        
    
</div>

                
            
        </div>
    </div>
</div>



<div class="moto-widget moto-widget-row row-gutter-0 moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto" data-grid-type="xs" data-widget="row" data-spacing="sama" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-1 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="aaaa" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_normal"><span class="moto-color1_3"><span class="fa"></span></span></p></div>
</div>
        
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-11 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small" data-widget="text" data-preset="default" data-spacing="aaas" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_217"><a href="tel:+8809610223344" data-action="call" class="moto-link">+880 9610-223344</a></p></div>
</div>
        
    
</div>

                
            
        </div>
    </div>



    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-1 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="aaaa" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_normal"><span class="moto-color1_3"><span class="fa"></span></span></p></div>
</div>
        
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-11 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small" data-widget="text" data-preset="default" data-spacing="aaas" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_217"><a href="#" data-action="call" class="moto-link">+8802 55033889, 55035340</a></p></div>
</div>
        
    
</div>

                
            
        </div>
    </div>




</div>



</div>









<div class="moto-widget moto-widget-row__column moto-cell col-sm-3 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="saaa" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_system_14"><span class="moto-color5_5">Branch Office</span></p></div>
</div><div class="moto-widget moto-widget-row row-gutter-0 moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-grid-type="xs" data-widget="row" data-spacing="saaa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-1 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="aaaa" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_normal"><span class="moto-color1_3"><span class="fa"></span></span></p></div>
</div></div><div class="moto-widget moto-widget-row__column moto-cell col-xs-11 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small" data-widget="text" data-preset="default" data-spacing="aaas" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_217">House: 35, Flat: 5, Road: 7, Block-G Banani, Dhaka–1213, Bangladesh</p></div>
</div></div>

                
            
        </div>
    </div>
</div><div class="moto-widget moto-widget-row row-gutter-0 moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-grid-type="xs" data-widget="row" data-spacing="saaa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-1 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="aaaa" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_normal"><span class="moto-color1_3"><span class="fa"></span></span></p></div>
</div>
        
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-11 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small" data-widget="text" data-preset="default" data-spacing="aaas" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_217">info@myolbd.com</p></div>
</div>
        
    
</div>

                
            
        </div>
    </div>
</div><div class="moto-widget moto-widget-row row-gutter-0 moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto" data-grid-type="xs" data-widget="row" data-spacing="sama" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-1 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="aaaa" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_normal"><span class="moto-color1_3"><span class="fa"></span></span></p></div>
</div>
        
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-11 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small" data-widget="text" data-preset="default" data-spacing="aaas" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_217"><a href="tel:+8809610223344" data-action="call" class="moto-link">+880 9610-223344</a></p></div>
</div>
        
    
</div>

                
            
        </div>
    </div>
</div>
</div>






<div class="moto-widget moto-widget-row__column moto-cell col-sm-3 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="saaa" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_system_14"><span class="moto-color5_5">New York Office</span></p></div>
</div><div class="moto-widget moto-widget-row row-gutter-0 moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-grid-type="xs" data-widget="row" data-spacing="saaa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-1 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="aaaa" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_normal"><span class="moto-color1_3"><span class="fa"></span></span></p></div>
</div></div><div class="moto-widget moto-widget-row__column moto-cell col-xs-11 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small" data-widget="text" data-preset="default" data-spacing="aaas" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_217">167-06 Hillside Avenue, Jamaica, New York</p></div>
</div></div>

                
            
        </div>
    </div>
</div>


<!-- <div class="moto-widget moto-widget-row row-gutter-0 moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-grid-type="xs" data-widget="row" data-spacing="saaa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-1 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="aaaa" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_normal"><span class="moto-color1_3"><span class="fa"></span></span></p></div>
</div>
        
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-11 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small" data-widget="text" data-preset="default" data-spacing="aaas" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_217">info@myolbd.com</p></div>
</div>
        
    
</div>

                
            
        </div>
    </div>
</div> -->



<div class="moto-widget moto-widget-row row-gutter-0 moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto" data-grid-type="xs" data-widget="row" data-spacing="sama" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-1 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="aaaa" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_normal"><span class="moto-color1_3"><span class="fa"></span></span></p></div>
</div>
        
    
</div>

                
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-11 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
        
            <div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-small" data-widget="text" data-preset="default" data-spacing="aaas" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_217"><a href="tel:+16785921000" data-action="call" class="moto-link">+1 678-592-1000</a></p></div>
</div>
        
    
</div>

                
            
        </div>
    </div>
</div>
</div>

<!-- <div class="moto-widget moto-widget-row__column moto-cell col-sm-3 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="saaa" data-animation="">
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_system_14"><span class="moto-color5_5">Sign up for updates</span></p></div>
</div><div data-widget-id="wid_1556107679_pyjdwe2oz" class="moto-widget moto-widget-mail_chimp moto-widget-contact_form moto-preset-default moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-medium moto-spacing-left-auto  " data-widget="mail_chimp" data-preset="default">
    <div ng-controller="widget.MailChimp.Controller" ng-init="listId = '';actionAfterSubmission={&quot;action&quot;:&quot;none&quot;,&quot;url&quot;:&quot;&quot;,&quot;target&quot;:&quot;_self&quot;,&quot;id&quot;:&quot;&quot;};resetAfterSubmission=false;">

        
        <form class="moto-widget-contact_form-form" role="form" name="subscribeForm" ng-submit="submit()" novalidate>
            <div ng-show="sending" class="contact-form-loading"></div>
                                                                        <div class="moto-widget-contact_form-group">
                            <label for="field_email" class="moto-widget-contact_form-label">Your E-mail</label>
                            <input type="text" class="moto-widget-contact_form-field moto-widget-contact_form-input" placeholder="Your E-mail *"  ng-blur="validate('email')" required  ng-model-options="{ updateOn: 'blur' }" name="email" id="field_email" ng-model="message.email"/>
                                                            <span class="moto-widget-contact_form-field-error ng-cloak" ng-cloak ng-show="subscribeForm.email.$invalid && !subscribeForm.email.$pristine && !subscribeForm.email.emailInvalid" >Field is required</span>
                                <span class="moto-widget-contact_form-field-error ng-cloak" ng-cloak ng-show="subscribeForm.email.emailInvalid && !subscribeForm.email.$pristine" >Incorrect email</span>
                                                    </div>
                                                                                                                                    
                            <input type="hidden" name="status" value="subscribed"/>
                <div class="moto-widget-contact_form-success ng-cloak" ng-cloak ng-show="emailSent">
                    You have successfully subscribed to the newsletter
                </div>
                <div class="moto-widget-contact_form-danger ng-cloak" ng-cloak ng-show="emailError && !isSubscribed">
                    You were not subscribed. Please try again
                </div>
                <div class="moto-widget-contact_form-danger ng-cloak" ng-cloak ng-show="emailError && isSubscribed">
                    You are already subscribed to this newsletter
                </div>
            
            <div class="moto-widget-contact_form-buttons">
                <div class="moto-widget moto-widget-button moto-preset-default moto-align-left" data-preset="default" data-align="left">
                    <a ng-click="submit()" class="moto-widget-button-link moto-size-small"
                       data-size="small"><span class="fa moto-widget-theme-icon"></span><span class="moto-widget-button-label">Subscribe</span></a>
                </div>
                <button type="submit" class="hidden"></button>
            </div>
        </form>
    </div>
</div></div> -->

                
            
        </div>
    </div>
</div><div class="moto-widget moto-widget-row row-fixed moto-bg-color_custom1 moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto" data-grid-type="sm" data-widget="row" data-spacing="sasa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-sm-12 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="aaaa" data-animation="">
    <!-- <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_217">Copyright © 2019 &nbsp; &nbsp;Privacy Policy</p></div> -->
    <div class="moto-widget-text-content moto-widget-text-editable"><p class="moto-text_217">© 2019. MY Outsourcing Limited. Developed by <a href="http://myolbd.com" target="_blank" style="color: #f53d05;">MY Outsourcing Limited</a>. All Rights Reserved.</p></div>
</div></div>

                
            
        </div>
    </div>
</div></div>
        </div>
    </div>
</div>  










