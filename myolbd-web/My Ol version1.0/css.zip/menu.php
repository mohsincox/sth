
    <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-sm-2 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-row row-gutter-0 moto-justify-content_center moto-spacing-top-small moto-spacing-right-auto moto-spacing-bottom-small moto-spacing-left-auto" data-grid-type="xs" data-widget="row" data-spacing="sasa" style="" data-bg-position="left top">
    
    
    <div class="container-fluid">
        <div class="row" data-container="container">
            
                
                    <div class="moto-widget moto-widget-row__column moto-cell col-xs-12 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div data-widget-id="wid_1556093122_8bwm2jlfc" class="moto-widget moto-widget-image moto-preset-default  moto-spacing-top-auto moto-spacing-right-small moto-spacing-bottom-auto moto-spacing-left-auto  " data-widget="image">
                        <a class="moto-widget-image-link moto-link" href="index.php"   data-action="page">
                <img data-src="images/mt-1806-logo-img.png" class="moto-widget-image-picture lazyload" data-id="187" title="" alt="">
            </a>
            </div>
        </div>

        <!-- <div class="moto-widget moto-widget-row__column moto-cell col-xs-8 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    
    
<div class="moto-widget moto-widget-text moto-preset-default moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-widget="text" data-preset="default" data-spacing="aaaa" data-animation="">
    
</div>

</div> -->

                
            
        </div>
    </div>
</div>
</div>



<div class="moto-widget moto-widget-row__column moto-cell col-sm-10 moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" style="" data-widget="row.column" data-container="container" data-spacing="aaaa" data-bg-position="left top">
    




    
<div data-widget-id="wid_1556093002_yp649hvmt" class="moto-widget moto-widget-menu moto-preset-default moto-align-right moto-align-center_mobile-h moto-spacing-top-auto moto-spacing-right-auto moto-spacing-bottom-auto moto-spacing-left-auto" data-preset="default" data-widget="menu">
            <a href="#" class="moto-widget-menu-toggle-btn"><i class="moto-widget-menu-toggle-btn-icon fa fa-bars"></i></a>
        <ul class="moto-widget-menu-list moto-widget-menu-list_horizontal">
            <li class="moto-widget-menu-item">
    <a href="index.php"   data-action="page" class="moto-widget-menu-link moto-widget-menu-link-level-1 moto-widget-menu-link-active moto-link">Home</a>
        </li>
        <!-- <li class="moto-widget-menu-item">
    <a href="solution.php"   data-action="page" class="moto-widget-menu-link moto-widget-menu-link-level-1 moto-widget-menu-link-active moto-link">Our Solutions</a>
        </li> -->

        <li class="moto-widget-menu-item moto-widget-menu-item-has-submenu">
    <a href="solution.php"   data-action="url" class="moto-widget-menu-link moto-widget-menu-link-level-1 moto-widget-menu-link-submenu moto-link">Solutions<span class="fa moto-widget-menu-link-arrow"></span></a>
                <ul class="moto-widget-menu-sublist">
                    <li class="moto-widget-menu-item">
    <a href="solution.php"   data-action="page" class="moto-widget-menu-link moto-widget-menu-link-level-2 moto-widget-menu-link-active moto-link">Call Center Solutions</a>
        </li>
                    <li class="moto-widget-menu-item">
    <a href="solution.php"   data-action="page" class="moto-widget-menu-link moto-widget-menu-link-level-2 moto-widget-menu-link-active moto-link">iPBX Solutions</a>
        </li>
                    <li class="moto-widget-menu-item">
    <a href="solution.php"   data-action="page" class="moto-widget-menu-link moto-widget-menu-link-level-2 moto-widget-menu-link-active moto-link">Web Development</a>
        </li>
                    <li class="moto-widget-menu-item">
    <a href="solution.php"   data-action="page" class="moto-widget-menu-link moto-widget-menu-link-level-2 moto-widget-menu-link-active moto-link">Lead Generation</a>
        </li>         
            </ul>

        </li>

        <li class="moto-widget-menu-item">
            <a href="overview.php"   data-action="page" class="moto-widget-menu-link moto-widget-menu-link-level-1 moto-widget-menu-link-active moto-link">Overview</a>
        </li>


        <!-- <li class="moto-widget-menu-item">
            <a href="service.php"   data-action="page" class="moto-widget-menu-link moto-widget-menu-link-level-1 moto-widget-menu-link-active moto-link">Services</a>
        </li> -->

        <li class="moto-widget-menu-item moto-widget-menu-item-has-submenu">
    <a href="service.php"   data-action="url" class="moto-widget-menu-link moto-widget-menu-link-level-1 moto-widget-menu-link-submenu moto-link">Services<span class="fa moto-widget-menu-link-arrow"></span></a>
                <ul class="moto-widget-menu-sublist">
                    <li class="moto-widget-menu-item">
    <a href="service.php"   data-action="page" class="moto-widget-menu-link moto-widget-menu-link-level-2 moto-widget-menu-link-active moto-link">Inbound Call Center Service</a>
        </li>
                    <li class="moto-widget-menu-item">
    <a href="service.php"   data-action="page" class="moto-widget-menu-link moto-widget-menu-link-level-2 moto-widget-menu-link-active moto-link">Outbound Call Center Service</a>
        </li>
                    <li class="moto-widget-menu-item">
    <a href="service.php"   data-action="page" class="moto-widget-menu-link moto-widget-menu-link-level-2 moto-widget-menu-link-active moto-link">Video Surveillance Monitoring</a>
        </li>
                    <li class="moto-widget-menu-item">
    <a href="service.php"   data-action="page" class="moto-widget-menu-link moto-widget-menu-link-level-2 moto-widget-menu-link-active moto-link">Non-voice & Back Office Support</a>
        </li>         
            </ul>

        </li>

        <li class="moto-widget-menu-item">
            <a href="award.php"   data-action="page" class="moto-widget-menu-link moto-widget-menu-link-level-1 moto-widget-menu-link-active moto-link">Awards & Achievements</a>
        </li>

        <!-- <li class="moto-widget-menu-item">
            <a href="gallery.php"   data-action="page" class="moto-widget-menu-link moto-widget-menu-link-level-1 moto-widget-menu-link-active moto-link">Gallery & Video</a>
        </li> -->

        <li class="moto-widget-menu-item moto-widget-menu-item-has-submenu">
    <a href="gallery.php"   data-action="url" class="moto-widget-menu-link moto-widget-menu-link-level-1 moto-widget-menu-link-submenu moto-link">Gallery<span class="fa moto-widget-menu-link-arrow"></span></a>
                <ul class="moto-widget-menu-sublist">
                    <li class="moto-widget-menu-item">
    <a href="gallery.php"   data-action="page" class="moto-widget-menu-link moto-widget-menu-link-level-2 moto-widget-menu-link-active moto-link">Image</a>
        </li>
                    <li class="moto-widget-menu-item">
    <a href="gallery.php"   data-action="page" class="moto-widget-menu-link moto-widget-menu-link-level-2 moto-widget-menu-link-active moto-link">Video</a>
        </li>
                    
                     
            </ul>

        </li>

        <li class="moto-widget-menu-item">
            <a href="contact-us.php"   data-action="page" class="moto-widget-menu-link moto-widget-menu-link-level-1 moto-widget-menu-link-active moto-link">Contact Us</a>
        </li>

        

        <!-- <li class="moto-widget-menu-item moto-widget-menu-item-has-submenu">
    <a href="#"   data-action="url" class="moto-widget-menu-link moto-widget-menu-link-level-1 moto-widget-menu-link-submenu moto-link">All blocks<span class="fa moto-widget-menu-link-arrow"></span></a>
                <ul class="moto-widget-menu-sublist">
                    <li class="moto-widget-menu-item">
    <a href="/#contact-us"   data-action="page" class="moto-widget-menu-link moto-widget-menu-link-level-2 moto-widget-menu-link-active moto-link">Contact us</a>
        </li>
                    <li class="moto-widget-menu-item">
    <a href="/#offers"   data-action="page" class="moto-widget-menu-link moto-widget-menu-link-level-2 moto-widget-menu-link-active moto-link">Offers</a>
        </li>
                    <li class="moto-widget-menu-item">
    <a href="/#overview"   data-action="page" class="moto-widget-menu-link moto-widget-menu-link-level-2 moto-widget-menu-link-active moto-link">Overview</a>
        </li>
                    <li class="moto-widget-menu-item">
    <a href="/#services"   data-action="page" class="moto-widget-menu-link moto-widget-menu-link-level-2 moto-widget-menu-link-active moto-link">Services</a>
        </li>
                    
                    <li class="moto-widget-menu-item">
    <a href="/#gallery"   data-action="page" class="moto-widget-menu-link moto-widget-menu-link-level-2 moto-widget-menu-link-active moto-link">Gallery</a>
        </li>
                    <li class="moto-widget-menu-item">
    <a href="/#testimonials"   data-action="page" class="moto-widget-menu-link moto-widget-menu-link-level-2 moto-widget-menu-link-active moto-link">Testimonials</a>
        </li>
                    
                    <li class="moto-widget-menu-item">
    <a href="/#support"   data-action="page" class="moto-widget-menu-link moto-widget-menu-link-level-2 moto-widget-menu-link-active moto-link">Support</a>
        </li>
            </ul>

        </li> -->        


    </ul>
    </div>








</div>          
            
        </div>