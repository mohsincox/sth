class Env {
  static String URL_PREFIX = "http://192.168.100.75/laravel55/public/api";
}
