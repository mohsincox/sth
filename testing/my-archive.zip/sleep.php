<?php
while(1) 
{
   sleep(5); //after 60s
   include('insert.php');
}
?>